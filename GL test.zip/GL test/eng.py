delimiter = "-"
currency_delimiter = " and "
currency_unit = ['dollars', 'dollar']
currency_cent = ['cents', 'cent']
numerators = [
 "",
 "one",
 "two",
 "three",
 "four",
 "five",
 "six",
 "seven",
 "eight",
 "nine",
 "ten",
 "eleven",
 "twelve",
 "thirteen",
 "fourteen",
 "fifteen",
 "sixteen",
 "seventeen",
 "eighteen",
 "nineteen"
]
tens = [
 "",
 "ten",
 "twenty",
 "thirty",
 "forty",
 "fifty",
 "sixty",
 "seventy",
 "eighty",
 "ninety"
]
hundreds = [
 "",
 "one hundred",
 "two hundred",
 "three hundred",
 "four hundred",
 "five hundred",
 "six hundred",
 "seven hundred",
 "eight hundred",
 "nine hundred"
]
ranges = [
 '',
 'thousand',
 'million',
 'billion'
]
ranges_single = []
ranges_multiple = []
correction_list = []
